<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lotteries Diarias</title>
    <style type="text/css">
        *{
            margin: 0px;
            padding: 0px;
        }
        body{
            font-family: sans-serif;
            font-size: 18px;
        }
        .mainwrp{
            font-size: 20px;
            font-weight: bold;
            text-align: center;
        }
        table{
            margin: 20px auto;
            width: 90%;
        }
        .table1{
            border: 1px solid black;
        }
        .table1 td{
            border-top: 1px solid black;
            border-bottom: 1px solid black;
        }
        .height{
            line-height: 35px;
            padding: 3px 5px;
            font-weight: bold;
        }
        .height td{
            padding: 3px 8px;
            font-size: 30px;
        }
        .height1 td{
            padding: 3px 8px;
            font-size: 20px;
            font-weight: bold;
        }
        /* Hide the print button when printing */
        @media  print {
            button {
                display: none;
            }
        }
        
        button{
            padding: 15px;
            margin: 50px;
            color: white;
            background-color: darkblue;
            border: none;
            cursor:pointer;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <button class="" onclick="window.print()">Print</button>
    <center>
        <img src="<?php echo e(asset('assets/images/logo.svg')); ?>" alt="company logo">
    </center>
    <table cellpadding="5px" cellspacing="5px">
        <tr>
            <th width="40%" align="left">Fecha y hora:</th>
            <?php
    $orderDate = $data['lotteryData']['adddatetime'];
    $formattedDate = \Carbon\Carbon::parse($orderDate)->format('d/m/Y h:i');
?>



            <td><?php echo e($formattedDate); ?></td>
        </tr>
        <tr>
            <th width="40%" align="left">Vendetor:</th>
           <td><?php echo e(isset($data['lotteryData']['vendor_name']) ? $data['lotteryData']['vendor_name'] : 'N/A'); ?></td>

        </tr>
        <tr>
            <th width="40%" align="left">Cliente</th>
            <td><?php echo e($data['lotteryData']['client_name']); ?></td>
        </tr>
    </table>
    <table class="table1" cellspacing="0" cellpadding="5px">
        <tr class="height1">
            <td>Numero</td>
            <td></td>
            <td align="right">Pedazos</td>
        </tr>
           
        <?php
            $groupedItems = collect($data['lotteryData']['order_items'])->groupBy('product_id');
        ?>

        <?php $__currentLoopData = $groupedItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productId => $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td></td>
                <td align="center"><h3><?php echo e($items->first()['product_name']); ?></h3></td>
                <td></td>
            </tr>
            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="height">
                    <td><?php echo e($item['lot_number']); ?></td>
                    <td align="center">--</td>
                    <td align="right"><?php echo e($item['lot_frac']); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <tr class="height1">
            <td>Total:</td>
            <td></td>
            <td align="right">Q.<?php echo e($data['lotteryData']['grand_total']); ?></td>
        </tr>
    </table>
    <div class="mainwrp">
        !!!!!! REVISE SU TICKET <br> ANTES DE <br> RETIRARSE !!!!!!<br/>
        ¿DUDAS, QUEJAS O RECLAMOS? ESCRIBANOS AL WHATSAPP 5577-6908
    </div>
</body>
</html>
<?php /**PATH /home/freeiuse/thewebconcept/softwares/fiverr/lottery_manager/resources/views/print.blade.php ENDPATH**/ ?>