<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lotteries Diarias</title>
    <style type="text/css">
        * {
            margin: 0;
            padding: 0;
        }
        body {
            font-family: sans-serif;
            font-size: 16px;
        }
        .container {
            width: 90%;
            margin: 20px auto;
        }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        .header-info {
            font-size: 14px;
        }
        .header-info th {
            text-align: left;
        }
        .logo img {
            width: 80px;
        }
        .table-title {
            text-align: left;
            font-size: 18px;
            font-weight: bold;
            margin-top: 15px;
        }
        .table1 {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        .table1, .table1 td, .table1 th {
            border: 1px solid black;
        }
        .table1 th, .table1 td {
            padding: 10px;
            text-align: center;
        }
        .footer-text {
            text-align: center;
            font-weight: bold;
            margin-top: 20px;
            font-size: 14px;
        }
        /* Hide the print button when printing */
        @media  print {
            button {
                display: none;
            }
        }
        button {
            padding: 10px 20px;
            color: white;
            background-color: darkblue;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            margin: 20px auto;
            display: block;
        }
    </style>
</head>
<body>
    <button onclick="window.print()">Print</button>

    <div class="container">
        <!-- Header Section -->
        <div class="header">
            <table class="header-info">
                <tr>
                    <th>Fecha y hora:</th>
                    <td><?php echo e(\Carbon\Carbon::parse($data['lotteryData']['adddatetime'])->format('d/m/Y h:i')); ?></td>
                </tr>
                <tr>
                    <th>Vendedor:</th>
                    <td><?php echo e(isset($data['lotteryData']['vendor_name']) ? $data['lotteryData']['vendor_name'] : 'N/A'); ?></td>
                </tr>
                <tr>
                    <th>Cliente:</th>
                    <td><?php echo e($data['lotteryData']['client_name']); ?></td>
                </tr>
            </table>
            <div class="logo">
                <img src="<?php echo e(asset('assets/images/logo.svg')); ?>" alt="company logo">
            </div>
        </div>
                <?php
                    $groupedItems = collect($data['lotteryData']['order_items'])->groupBy('product_id');
                ?>
        <!-- Lottery Table Section -->
        <div>
    <?php $__currentLoopData = $groupedItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productId => $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <!-- Display product name only once per product group -->
        <div class="table-title"><?php echo e($items->first()['product_name']); ?></div>

        <!-- Table for items under this product name -->
        <table class="table1">
            <tr>
                <th>Numero</th>
                <th>Pedazos</th>
            </tr>
            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item['lot_number']); ?></td>
                    <td><?php echo e($item['lot_frac']); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <!-- Footer Section -->
    <div class="footer-text">
        !!!!!! REVISE SU TICKET <br> ANTES DE <br> RETIRARSE !!!!!!<br/>
        ¿DUDAS, QUEJAS O RECLAMOS? ESCRIBANOS AL WHATSAPP 5577-6908
    </div>
</div>

</body>
</html>
<?php /**PATH /home/healihvb/phoenix/resources/views/print.blade.php ENDPATH**/ ?>